import { useState } from "react";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Button } from "./components/ui/button";

const distritos = [
  { nombre: "Arán", representantes: 11 },
  { nombre: "Arrecife", representantes: 7 },
  { nombre: "Catania", representantes: 8 },
  { nombre: "Concordia", representantes: 12 },
  { nombre: "Hellania", representantes: 17 },
  { nombre: "Poniente", representantes: 15 },
  { nombre: "Puerto Viejo", representantes: 13 },
  { nombre: "Santa Carmen", representantes: 32 },
  { nombre: "Santa Juana", representantes: 12 },
  { nombre: "Tres Torres", representantes: 7 },
  { nombre: "Valia", representantes: 28 },
  { nombre: "Colina", representantes: 3 },
  { nombre: "Talismán", representantes: 2 }
];

const partidos = ["UMA", "PSA", "PA", "PRC", "UDMA", "PV", "PMC", "PIC"];

function aplicarDhondt(votos, escanos) {
  const cocientes = [];
  for (let i = 0; i < partidos.length; i++) {
    for (let j = 1; j <= escanos; j++) {
      cocientes.push({ partido: partidos[i], valor: votos[i] / j });
    }
  }
  cocientes.sort((a, b) => b.valor - a.valor);
  const seleccionados = cocientes.slice(0, escanos);
  const resultado = {};
  partidos.forEach(p => resultado[p] = 0);
  seleccionados.forEach(e => resultado[e.partido]++);
  return resultado;
}

export default function RepartoEscanos() {
  const [votosPorDistrito, setVotosPorDistrito] = useState(
    distritos.map(() => Array(partidos.length).fill(""))
  );
  const [resultados, setResultados] = useState(null);

  const calcularResultados = () => {
    const totales = {};
    partidos.forEach(p => (totales[p] = 0));

    const porDistrito = distritos.map((distrito, i) => {
      const votos = votosPorDistrito[i].map(v => parseFloat(v) || 0);
      const resultado = aplicarDhondt(votos, distrito.representantes);
      partidos.forEach(p => (totales[p] += resultado[p]));
      return { distrito: distrito.nombre, resultado };
    });

    setResultados({ porDistrito, totales });
  };

  return (
    <div>
      {distritos.map((distrito, i) => (
        <Card key={i}>
          <CardContent>
            <h2>{distrito.nombre}</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '0.5rem' }}>
              {partidos.map((partido, j) => (
                <Input
                  key={j}
                  type="number"
                  placeholder={`% ${partido}`}
                  value={votosPorDistrito[i][j]}
                  onChange={e => {
                    const nuevosVotos = [...votosPorDistrito];
                    nuevosVotos[i][j] = e.target.value;
                    setVotosPorDistrito(nuevosVotos);
                  }}
                />
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
      <Button onClick={calcularResultados}>Calcular Resultados</Button>

      {resultados && (
        <div>
          <h2>Resultados por Distrito</h2>
          {resultados.porDistrito.map((r, i) => (
            <div key={i}>
              <h3>{r.distrito}</h3>
              <p>{partidos.map(p => `${p}: ${r.resultado[p]}`).join(" | ")}</p>
            </div>
          ))}
          <h2>Resultado Total</h2>
          <p>{partidos.map(p => `${p}: ${resultados.totales[p]}`).join(" | ")}</p>
        </div>
      )}
    </div>
  );
}