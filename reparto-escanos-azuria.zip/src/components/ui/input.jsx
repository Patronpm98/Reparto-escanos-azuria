export function Input(props) {
  return <input {...props} style={{ padding: '0.5rem', border: '1px solid #ccc', borderRadius: '5px' }} />;
}