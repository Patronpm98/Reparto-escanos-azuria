export function Button({ children, onClick }) {
  return <button onClick={onClick} style={{ padding: '0.75rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '5px' }}>{children}</button>;
}