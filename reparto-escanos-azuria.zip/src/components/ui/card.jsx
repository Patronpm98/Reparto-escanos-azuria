export function Card({ children }) {
  return <div style={{ border: '1px solid #ccc', borderRadius: '10px', marginBottom: '1rem' }}>{children}</div>;
}
export function CardContent({ children }) {
  return <div style={{ padding: '1rem' }}>{children}</div>;
}